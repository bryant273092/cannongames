	In this demo, Player 1 is controlled by only mouse/keyboard. Player 2 is controlled by only controller. 
	Press start key on the contoller to add second player.
	If you don't have controller available, you can play single player practice mode. 
	Or alternatively, you can press SPACE or ENTER key on your keyboard at lobby screen to add a dummy second player.

Known Bugs:
	Holding fire button prevent you from picking up a new weapon. You have to release fire button when pick it up.
	The graphics rendering for destructible objects might go wrong in rare cases.
